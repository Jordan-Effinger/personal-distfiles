/*	FIle: mkrfiles-0.c
	AUTHOR: Jordan Effinger
	DATE: 28 May 2023 
	VERSION: 0
	LICENSE: BSD 3-Clause

	COMMENT: A minimal system utility to create
	random files within the /tmp/ file system.
	The emphasis was on secure code that checks
	for early error and printing verbose error
	messages. 
*/

#include <errno.h>
#include <limits.h>
#include <string.h>
#include <unistd.h>

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>


void
print_error(const char *prog_name, const pid_t pid, const char *file, unsigned line, unsigned errnum)
{
	fprintf(stderr, "[%s: %u [%s: line %u] Errno: %u, Error: %s\n",
			prog_name, pid, file, line, errnum, strerror(errnum)
			);	
}

void
usage(const char *prog_name)
{
	printf("%s -nv\n"
			"-n number of files"
			"-v verbose",
			prog_name
			);
}

int
main(int argc, char **argv)
{
	const pid_t main_pid = getpid();
	const char *prog_name;
	strncpy(prog_name, getprogname(), strlen(getprogname()));

	bool number_flag, verbose_flag = false;
	unsigned long file_count;

	if( argc > 1)
	{
		int ch;
		while( (ch = getopt(argc, argv, "n:v") ) != -1)
		{
			switch(ch)
			{
				case 'n':
					errno = 0;
					number_flag = true;
					file_count = strtoul(optarg, NULL,0);
					if(errno != 0)
					{
						print_error(prog_name, main_pid, __FILE__, __LINE__, errno);
						return errno;
						break;
					}
					
					/*	A) Keeping file_count below some arbitrary measure below the limit
						   OPEN_MAX is intended as a means of preventing this process or
						   multiples runs from cluttering the disk or from hitting the limit
						   for open files for all process/the system.
						B) However, the use of the developer-imposed limit being 255 below
						   that of OPEN_MAX is fairly arbitrary and a gut instinct.In future
						   versions I intend to replace this with a dynamic and more statistical	
						   basis.
					*/
					if( file_count > (OPEN_MAX-255) )
					{
						print_error(prog_name, main_pid, __FILE__, __LINE__, EMFILE);
					}
					break;

				case 'v':
					verbose_flag = true;
					break;

				default:
					print_error(prog_name, main_pid, __FILE__, __LINE__, EINVAL);
					return EINVAL;
					break;
			}
		}
	}

	char filename[] = "/tmp/rfile-XXX";
	size_t len = strlen(filename);
	int res;

	if(number_flag)
	{
		for(unsigned long idx = 0; idx < file_count; idx++ )
		{ 
			errno = 0;
			res = 0;
			if(verbose_flag){ printf("Making rfile.\n"); }

			res = mkstemp(filename);
			if(res == -1)
			{
				print_error(prog_name, main_pid, __FILE__, __LINE__, errno);
				return errno;
			}
			for(size_t jdx = 1; jdx != 4; jdx++)
			{
				filename[len-jdx]='X';
			}
		}
	}			
	else
	{
			if(verbose_flag){ printf("Making rfile.\n"); }	
			res = mkstemp(filename);
			if(res == -1)
			{
				print_error(prog_name, main_pid, __FILE__, __LINE__, errno);
			}
	}
	
	return EXIT_SUCCESS;
}
